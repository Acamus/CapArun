package org.cap.capstore.dto;

public class Merchant {

	private int merchantId;
	private float rating;

	public Merchant() {

	}

	public Merchant(int merchantId, float rating) {
		super();
		this.merchantId = merchantId;
		this.rating = rating;
	}

	public int getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(int merchantId) {
		this.merchantId = merchantId;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "Merchant [merchantId=" + merchantId + ", rating=" + rating + "]";
	}
}