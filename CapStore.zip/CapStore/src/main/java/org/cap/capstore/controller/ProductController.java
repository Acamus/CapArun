package org.cap.capstore.controller;

import java.util.List;

import javax.servlet.http.HttpServlet;

import org.cap.capstore.dto.Category;
import org.cap.capstore.dto.Product;
import org.cap.capstore.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProductController {

	@Autowired
	private ProductService productService;

	@RequestMapping("/category")
	public String showCategory(ModelMap map) {
		map.put("ref1", new Category());
		map.put("ref2", new Product());
		map.put("categories", productService.getAllCategories());
		map.put("products", productService.getProductDetails());
		return "capStoreHomePage";
	}

}