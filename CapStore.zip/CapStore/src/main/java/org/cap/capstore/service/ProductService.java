package org.cap.capstore.service;

import java.util.List;

import org.cap.capstore.dto.Category;
import org.cap.capstore.dto.Product;

public interface ProductService {

	public List<Category> getAllCategories();
	public List<Product> getProductDetails();
}