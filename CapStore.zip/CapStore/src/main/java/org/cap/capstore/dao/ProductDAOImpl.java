package org.cap.capstore.dao;

import java.util.List;

import org.cap.capstore.dto.Category;
import org.cap.capstore.dto.Product;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class ProductDAOImpl implements ProductDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Transactional
	@Override
	public List<Category> getAllCategories() {
		return sessionFactory.getCurrentSession().createQuery("from Category").list();
	}

	@Transactional
	@Override
	public List<Product> getProductDetails() {

		return sessionFactory.getCurrentSession().createQuery("from Product").list();
	}
}