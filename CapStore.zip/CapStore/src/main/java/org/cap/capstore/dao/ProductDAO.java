package org.cap.capstore.dao;

import java.util.List;

import org.cap.capstore.dto.Category;
import org.cap.capstore.dto.Product;

public interface ProductDAO {
	
	public List<Category> getAllCategories();
	public List<Product> getProductDetails();
	

}
