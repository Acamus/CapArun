package org.cap.capstore.dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="Product")
public class Product {

	@Id
	private int productId;
	private String productName;
	//private Category category;
	private long stock;
	private long viewCount;
	private float rating;
	private double price;
	//private List<Merchant> merchant;
	//private List<Feedback> feedback;

	public Product() {
	}

	public Product(int productId, String productName, long stock, long viewCount, float rating, double price) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.stock = stock;
		this.viewCount = viewCount;
		this.rating = rating;
		this.price = price;
	}

	/*public Product(int productId, String productName, Category category, long stock, long viewCount, float rating,
			double price, List<Merchant> merchant, List<Feedback> feedback) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.category = category;
		this.stock = stock;
		this.viewCount = viewCount;
		this.rating = rating;
		this.price = price;
		this.merchant = merchant;
		this.feedback = feedback;
	}
*/
	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	/*public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}*/

	public long getStock() {
		return stock;
	}

	public void setStock(long stock) {
		this.stock = stock;
	}

	public long getViewCount() {
		return viewCount;
	}

	public void setViewCount(long viewCount) {
		this.viewCount = viewCount;
	}

	public float getRating() {
		return rating;
	}

	public void setRating(float rating) {
		this.rating = rating;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", stock=" + stock + ", viewCount="
				+ viewCount + ", rating=" + rating + ", price=" + price + "]";
	}

	/*public List<Merchant> getMerchant() {
		return merchant;
	}

	public void setMerchant(List<Merchant> merchant) {
		this.merchant = merchant;
	}

	public List<Feedback> getFeedback() {
		return feedback;
	}

	public void setFeedback(List<Feedback> feedback) {
		this.feedback = feedback;
	}*/

	/*@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", category=" + category
				+ ", stock=" + stock + ", viewCount=" + viewCount + ", rating=" + rating + ", price=" + price + "]";
	}*/
}