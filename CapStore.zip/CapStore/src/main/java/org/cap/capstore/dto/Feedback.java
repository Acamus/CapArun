package org.cap.capstore.dto;

public class Feedback {

	private int feedbackId;
	private String text;

	public Feedback() {
	}

	public Feedback(int feedbackId, String text) {
		super();
		this.feedbackId = feedbackId;
		this.text = text;
	}

	public int getFeedbackId() {
		return feedbackId;
	}

	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	@Override
	public String toString() {
		return "Feedback [feedbackId=" + feedbackId + ", text=" + text + "]";
	}
}